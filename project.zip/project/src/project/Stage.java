package project;
import java.util.Scanner;

public class Stage {
	String [] Pokemons = {"rayquaza", "jessie", "misty"};
	
	public void catchtime() {
		System.out.println("catch time! choose a pokemon to catch:");
		
		for (int i = 0; i < Pokemons.length; i++) {
			
			System.out.println((i + 1) + " " + Pokemons[i]);
			
		}
		System.out.println("GAME START");
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Number 1---3: ");
		int choice = scanner.nextInt();
		
		if (choice >= 1 && choice <= 3) {
			System.out.println("you caught " + Pokemons[choice - 1] + "!");
			
		}  else {
			System.out.println("invalid choice.No pokemon caught GAME OVER!");
					 
			
		}
	}
}
		
		
			
		
		
		
		
		
	


