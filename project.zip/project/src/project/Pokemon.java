package project;

public class Pokemon {
	String name;
	
	public Pokemon (String name) {
	this.name = name;
	}
	
	public String getname() {
		return name;
	}
}	
	
	
	
	
	
	
	
	


