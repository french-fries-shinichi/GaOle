package project;

public class Teststage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stage currentstage = new Stage();
		currentstage.catchtime();

	}

}
